export const TG_TOKEN = "6370720391:AAHh7wGdUPCfySZ1THnOKFLXZj--G0V89hA";
//export const TG_TOKEN = "5811551715:AAH6Ky64LEZEHIaMLcmi7xIC3z7t3aSpFDk";
export const MONGO_ROOT = 'mongodb+srv://songil:YHONhFTJXhCI1Jic@cluster0.bnlf1sq.mongodb.net/tgbot?retryWrites=true&w=majority';

